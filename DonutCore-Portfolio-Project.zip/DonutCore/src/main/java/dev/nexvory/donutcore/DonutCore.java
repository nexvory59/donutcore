package dev.nexvory.donutcore;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

public final class DonutCore extends JavaPlugin {
    private static final DateTimeFormatter FILE_TIME =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC);

    private BukkitTask sampler;
    private long startedAt;
    private long lastAlertAt;
    private double latestTps = 20.0;
    private double latestMspt = 0.0;
    private int latestEntities;
    private int latestChunks;
    private long latestUsedMemoryMb;
    private long latestMaxMemoryMb;
    private final AtomicLong samples = new AtomicLong();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        startedAt = System.currentTimeMillis();

        int interval = Math.max(1, getConfig().getInt("sample-interval-seconds", 1));
        sampler = Bukkit.getScheduler().runTaskTimer(this, this::sampleServer,
                1L, interval * 20L);

        getLogger().info("DonutCore enabled. Diagnostics sampling every " + interval + "s.");
        getLogger().info("Use /donutcore status or /donutcore report.");
    }

    @Override
    public void onDisable() {
        if (sampler != null) sampler.cancel();
        getLogger().info("DonutCore disabled after " + samples.get() + " diagnostic samples.");
    }

    // All Bukkit/Paper server reads happen on the main thread.
    private void sampleServer() {
        double[] tps = Bukkit.getTPS();
        latestTps = tps.length == 0 ? 20.0 : tps[0];
        latestMspt = Bukkit.getAverageTickTime();

        int entities = 0;
        int chunks = 0;
        for (World world : Bukkit.getWorlds()) {
            entities += world.getEntities().size();
            chunks += world.getLoadedChunks().length;
        }
        latestEntities = entities;
        latestChunks = chunks;

        Runtime runtime = Runtime.getRuntime();
        latestUsedMemoryMb = (runtime.totalMemory() - runtime.freeMemory()) / 1_048_576L;
        latestMaxMemoryMb = runtime.maxMemory() / 1_048_576L;
        samples.incrementAndGet();

        double tpsLimit = getConfig().getDouble("alert-tps-below", 18.5);
        double msptLimit = getConfig().getDouble("alert-mspt-above", 50.0);
        long cooldown = getConfig().getLong("alert-cooldown-seconds", 60) * 1000L;
        long now = System.currentTimeMillis();

        if ((latestTps < tpsLimit || latestMspt > msptLimit)
                && now - lastAlertAt >= cooldown) {
            lastAlertAt = now;
            String reason = latestTps < tpsLimit
                    ? String.format(Locale.US, "TPS is %.2f (threshold %.2f)", latestTps, tpsLimit)
                    : String.format(Locale.US, "MSPT is %.2f (threshold %.2f)", latestMspt, msptLimit);
            getLogger().warning("[Health Alert] " + reason
                    + ". Entities=" + latestEntities + ", loadedChunks=" + latestChunks);
            for (CommandSender online : Bukkit.getOnlinePlayers()) {
                if (online.hasPermission("donutcore.admin")) {
                    online.sendMessage(ChatColor.RED + "[DonutCore] " + reason);
                }
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("donutcore.admin")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sendStatus(sender);
            return true;
        }

        if (args[0].equalsIgnoreCase("report")) {
            // Capture a Bukkit-safe snapshot before moving file I/O off the main thread.
            String report = buildReport();
            sender.sendMessage(ChatColor.YELLOW + "[DonutCore] Generating diagnostic report...");
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> writeReport(sender, report));
            return true;
        }

        sender.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " <status|report>");
        return true;
    }

    private void sendStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "===== DonutCore Server Health =====");
        sender.sendMessage(ChatColor.YELLOW + "TPS (1m): " + colorTps(latestTps)
                + String.format(Locale.US, "%.2f", latestTps));
        sender.sendMessage(ChatColor.YELLOW + "Average MSPT: " + ChatColor.WHITE
                + String.format(Locale.US, "%.2f ms", latestMspt));
        sender.sendMessage(ChatColor.YELLOW + "Entities: " + ChatColor.WHITE + latestEntities);
        sender.sendMessage(ChatColor.YELLOW + "Loaded chunks: " + ChatColor.WHITE + latestChunks);
        sender.sendMessage(ChatColor.YELLOW + "Memory: " + ChatColor.WHITE
                + latestUsedMemoryMb + " / " + latestMaxMemoryMb + " MB");
        sender.sendMessage(ChatColor.YELLOW + "Uptime: " + ChatColor.WHITE + formatDuration(
                System.currentTimeMillis() - startedAt));
        sender.sendMessage(ChatColor.GRAY + "Samples collected: " + samples.get());
    }

    private ChatColor colorTps(double tps) {
        if (tps >= 19.5) return ChatColor.GREEN;
        if (tps >= 18.0) return ChatColor.YELLOW;
        return ChatColor.RED;
    }

    private String buildReport() {
        StringBuilder worlds = new StringBuilder();
        for (World world : Bukkit.getWorlds()) {
            if (!worlds.isEmpty()) worlds.append('\n');
            worlds.append("- ").append(world.getName())
                    .append(": players=").append(world.getPlayers().size())
                    .append(", entities=").append(world.getEntities().size())
                    .append(", loadedChunks=").append(world.getLoadedChunks().length);
        }

        return """
                DonutCore Diagnostic Report
                Generated: %s
                Plugin version: %s
                Server: %s
                Minecraft: %s
                Online players: %d
                TPS (1m): %.2f
                Average MSPT: %.2f
                Total entities: %d
                Total loaded chunks: %d
                Used memory MB: %d
                Max memory MB: %d
                Uptime: %s
                Samples collected: %d

                World breakdown:
                %s
                """.formatted(
                Instant.now(), getPluginMeta().getVersion(), Bukkit.getName(),
                Bukkit.getMinecraftVersion(), Bukkit.getOnlinePlayers().size(),
                latestTps, latestMspt, latestEntities, latestChunks,
                latestUsedMemoryMb, latestMaxMemoryMb,
                formatDuration(System.currentTimeMillis() - startedAt),
                samples.get(), worlds);
    }

    private void writeReport(CommandSender sender, String report) {
        try {
            Path directory = getDataFolder().toPath().resolve("reports");
            Files.createDirectories(directory);
            Path file = directory.resolve("health-" + FILE_TIME.format(Instant.now()) + ".txt");
            Files.writeString(file, report, StandardCharsets.UTF_8);
            Bukkit.getScheduler().runTask(this, () ->
                    sender.sendMessage(ChatColor.GREEN + "[DonutCore] Report saved: "
                            + getDataFolder().getName() + "/reports/" + file.getFileName()));
        } catch (IOException exception) {
            getLogger().severe("Could not write diagnostic report: " + exception.getMessage());
            Bukkit.getScheduler().runTask(this, () ->
                    sender.sendMessage(ChatColor.RED + "[DonutCore] Could not save report. Check console."));
        }
    }

    private String formatDuration(long millis) {
        long seconds = millis / 1000L;
        long days = seconds / 86400L;
        long hours = (seconds % 86400L) / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainingSeconds = seconds % 60L;
        return days + "d " + hours + "h " + minutes + "m " + remainingSeconds + "s";
    }
}
