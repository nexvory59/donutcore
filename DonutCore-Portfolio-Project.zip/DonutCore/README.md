# DonutCore

A portfolio-grade Paper plugin demonstrating server-side Java development.

## Features
- Periodic server health sampling (TPS, average MSPT, entities, loaded chunks, memory).
- Configurable performance thresholds and alert cooldown.
- Permission-gated `/donutcore status` diagnostics.
- `/donutcore report` exports a timestamped text report.
- Bukkit/Paper server data is collected on the main thread; report file I/O runs asynchronously.

## Requirements
- Java 21
- Paper 1.21.8 (or a compatible Paper build)
- Maven 3.9+

## Build
```bash
mvn clean package
```
The plugin JAR will be in `target/DonutCore-1.0.0.jar` (artifact filename: `donutcore-1.0.0.jar`).

## Install
1. Build the project.
2. Put the JAR in your test server's `plugins/` directory.
3. Start the server and review `plugins/DonutCore/config.yml`.
4. Run `/donutcore status` or `/donutcore report` as an operator.

## Commands
- `/donutcore status` — displays the latest health sample.
- `/donutcore report` — creates a diagnostic report in `plugins/DonutCore/reports/`.

## Permission
- `donutcore.admin` (default: operators)

## Important portfolio note
This is an independent demonstration project, not an official DonutSMP plugin and not affiliated with DonutSMP. Test it on a local Paper server before submitting it. Do not claim it has been deployed on DonutSMP. For a stronger application, add automated tests, CI, structured logging, and a short demo video.
